const { test, expect } = require('@playwright/test');

const PAGE_PATH = '/products/developer-tools/validators/file/';
const validJson = JSON.stringify({
  title: 'CoreCraft Genesis',
  type: 'object',
  properties: {
    name: { type: 'string' },
    enabled: { type: 'boolean' }
  }
}, null, 2);

async function uploadMetafields(page, content = validJson) {
  await page.locator('#fileInput').setInputFiles({
    name: 'metafields.json',
    mimeType: 'application/json',
    buffer: Buffer.from(content, 'utf8')
  });
}

async function expectReportText(page, text) {
  await expect(page.locator('body')).toContainText(text);
}

test.describe('CoreCraft Genesis File Validator', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(PAGE_PATH);
    await expect(page.locator('#fileInput')).toHaveAttribute('type', 'file');
  });

  test('validiert metafields.json ohne optionale Regeln', async ({ page }) => {
    await uploadMetafields(page);

    await expectReportText(page, 'metafields.json');
    await expectReportText(page, 'application/json');
    await expectReportText(page, 'Datei wurde erfolgreich ausgewählt');
    await expectReportText(page, 'Datei konnte als Text gelesen werden');
    await expectReportText(page, 'Datei enthält gültiges JSON');
    await expectReportText(page, 'Keine Namensregel definiert');
    await expectReportText(page, 'Keine Erweiterungsregel definiert');
    await expectReportText(page, 'Keine Größenregel definiert');
  });

  test('besteht mit korrekten Dateiregeln', async ({ page }) => {
    await page.locator('#expectedName').fill('metafields.json');
    await page.locator('#expectedExtensions').fill('json');
    await page.locator('#maxSize').fill('10');

    await uploadMetafields(page);

    await expectReportText(page, 'metafields.json');
    await expectReportText(page, 'Datei wurde erfolgreich ausgewählt');
    await expectReportText(page, 'Datei konnte als Text gelesen werden');
    await expectReportText(page, 'Datei enthält gültiges JSON');

    const body = page.locator('body');
    await expect(body).not.toContainText('Keine Namensregel definiert');
    await expect(body).not.toContainText('Keine Erweiterungsregel definiert');
    await expect(body).not.toContainText('Keine Größenregel definiert');
  });

  test('erkennt einen falschen erwarteten Dateinamen', async ({ page }) => {
    await page.locator('#expectedName').fill('wrong-file.json');
    await uploadMetafields(page);

    await expectReportText(page, 'metafields.json');
    await expectReportText(page, 'wrong-file.json');
    await expectReportText(page, 'Datei konnte als Text gelesen werden');
    await expectReportText(page, 'Datei enthält gültiges JSON');

    const bodyText = await page.locator('body').innerText();
    expect(bodyText).toMatch(/FAIL|nicht|abweich|erwart/i);
  });

  test('erkennt ungültige JSON-Syntax', async ({ page }) => {
    await uploadMetafields(page, '{"name": "broken",}');

    await expectReportText(page, 'metafields.json');
    const bodyText = await page.locator('body').innerText();
    expect(bodyText).toMatch(/JSON/i);
    expect(bodyText).toMatch(/FAIL|ungültig|Fehler|nicht gültig/i);
  });
});
